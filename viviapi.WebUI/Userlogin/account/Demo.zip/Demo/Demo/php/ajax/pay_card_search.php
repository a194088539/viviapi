<?php
error_reporting(0);
header('Content-Type:text/html;charset=GB2312');
include_once("../config/pay_config.php");
include_once("../Auyuw/class.Auyuw.php");
$Auyuw = new Auyuw();
$Auyuw->parter 		= $Auyuw_merchant_id;		//�̼�Id
$Auyuw->key 			= $Auyuw_merchant_key;	//�̼���Կ

$result	= $Auyuw->search($_POST['order_id']);

$data = '{"success": "'.$result.'","message": "'. $Auyuw->message .'"}';
die($data);
?>